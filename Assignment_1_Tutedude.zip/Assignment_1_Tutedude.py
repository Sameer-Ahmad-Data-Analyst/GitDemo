#Task 1
#Perform Basic Mathematical Operations.
a = 20
b = 30
print(a+b)

a = float(input ("Enter the first number: "))
b = float(input ("Enter the second number: "))

print(a+b)#Addition.
print(a-b)#Subraction.
print(a*b)#Miultiplication.
print(a/b)#Division.

#Task 2
#Create a Personalized Greeting.

first = input("Enter your first name: ")
last = input("Enter your last name: ")
print(f"Hello,{first} {last} Welcome to the Python program.")